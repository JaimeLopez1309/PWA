//serv work

if('service Worker' in navigator) {
    console.log ('service Worker is available');
        window.addEventListener('load', function(){
            this.navigator.serviceWorker.register('./dist/serviceWork.js')
            .then(Response=>console.log('Service Worker: ' + Response))
            .catch(err=>console.error(err));
        });


}
// routes/index.js

const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
    res.send('Ruta principal');
});

module.exports = router;
